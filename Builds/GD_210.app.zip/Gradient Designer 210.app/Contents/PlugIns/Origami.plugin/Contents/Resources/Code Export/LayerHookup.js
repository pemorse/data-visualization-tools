// Hook up variables to dom elements here

var layers = {
%@};