- (void)set%@Progress:(CGFloat)progress {
	_%@Progress = progress;
%@}