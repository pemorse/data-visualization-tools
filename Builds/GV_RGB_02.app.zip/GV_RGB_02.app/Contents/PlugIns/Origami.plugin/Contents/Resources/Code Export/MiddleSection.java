  public OrigamiAnimationView(Context context) {
    this(context, null);
  }

  public OrigamiAnimationView(Context context, AttributeSet attrs) {
    this(context, attrs, 0);
  }

  public OrigamiAnimationView(Context context, AttributeSet attrs, int defStyle) {
    super(context, attrs, defStyle);

    // Hook up variables to your views here