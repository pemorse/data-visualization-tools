static inline CGFloat POPDegreesToRadians(CGFloat degrees) {
	return M_PI * (degrees / 180.0);
}