  // %@ transition

  public void %@(boolean on) {
    %@Spring.setEndValue(on ? 1 : 0);
  }

  public void set%@Progress(float progress) {%@  }